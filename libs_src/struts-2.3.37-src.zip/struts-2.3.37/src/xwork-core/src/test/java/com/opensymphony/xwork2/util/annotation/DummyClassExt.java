package com.opensymphony.xwork2.util.annotation;

public final class DummyClassExt extends DummyClass {

    @MyAnnotation2
    public void anotherAnnotatedMethod() {
    }

}
